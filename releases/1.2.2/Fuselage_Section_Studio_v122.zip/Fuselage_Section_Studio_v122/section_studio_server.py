"""Local Section Studio launcher. Python 3.10+, standard library only."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import tempfile
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import xml.etree.ElementTree as ET
from native_audit import build_mesh, build_machline_mesh, verify_repair, FACTORS,process_failure
from machline_audit import settings as machline_settings, read_tri, inspect_machline
from assembly_audit import assembly, compare
from assembly_repair import repair_assembly
from job_manager import Jobs
from setup_checks import discover_executables,self_test
from local_storage import RecoveryStore,read_settings,write_settings
from version import VERSION
from instance_guard import InstanceGuard
from calculation import recover_interrupted, run_pipeline, normalize_plan, solver_path, discover_machline, listing as calculation_listing, load_report as calculation_report, bundle as calculation_bundle
from engine_control import engine_update

ROOT = Path(__file__).resolve().parent
MAX_INPUT = 64 * 1024 * 1024


def validate_executable(value):
    path = Path(str(value).strip().strip('"')).expanduser()
    if path.is_dir():
        path = path / ('vspscript.exe' if os.name == 'nt' else 'vspscript')
    if path.name.lower() not in ('vspscript.exe', 'vspscript') or not path.is_file():
        raise ValueError('Выбери vspscript.exe из папки OpenVSP, а не vsp.exe.')
    if os.name != 'nt' and not os.access(path, os.X_OK):
        raise ValueError('У vspscript нет разрешения на запуск.')
    return str(path.resolve())


def geoms(xml):
    if not isinstance(xml, str) or len(xml.encode('utf-8')) > 40_000_000:
        raise ValueError('Предел VSP3 — 40 МБ.')
    if re.search(r'<!DOCTYPE|<!ENTITY', xml, re.I):
        raise ValueError('XML с DTD или сущностями не поддерживается.')
    try:
        root = ET.fromstring(xml)
    except ET.ParseError as exc:
        raise ValueError('Некорректный XML VSP3.') from exc
    if root.tag != 'Vsp_Geometry':
        raise ValueError('Нужен файл VSP3 из OpenVSP 3.')
    nodes = root.findall('./Vehicle/Geom')
    stack, ranges, start = [], [], None
    pattern = r'<!--[\s\S]*?-->|<\?[\s\S]*?\?>|</?([A-Za-z_][\w:.-]*)\b[^>]*>'
    for match in re.finditer(pattern, xml):
        tag = match.group(1)
        if not tag:
            continue
        text = match.group(0)
        if text.startswith('</'):
            if tag == 'Geom' and stack == ['Vsp_Geometry', 'Vehicle', 'Geom']:
                ranges.append((start, match.end()))
            if stack:
                stack.pop()
        else:
            if tag == 'Geom' and stack == ['Vsp_Geometry', 'Vehicle']:
                start = match.start()
            if not text.endswith('/>'):
                stack.append(tag)
    if len(nodes) != len(ranges):
        raise ValueError('Не удалось выделить компоненты VSP3.')
    result = {}
    for node, bounds in zip(nodes, ranges):
        ident = node.findtext('ParmContainer/ID', '').strip()
        if not re.fullmatch(r'[A-Za-z0-9_]{1,40}', ident) or ident in result:
            raise ValueError('Некорректные или повторяющиеся ID компонентов.')
        result[ident] = (node.findtext('GeomBase/TypeName', ''), bounds)
    return result


def merge_selected(original, converted, selection):
    old, new = geoms(original), geoms(converted)
    for ident in sorted(selection, key=lambda item: old[item][1][0], reverse=True):
        if ident not in new:
            raise ValueError('OpenVSP не сохранил выбранный компонент.')
        lo, hi = old[ident][1]
        a, b = new[ident][1]
        original = original[:lo] + converted[a:b] + original[hi:]
    return original


def validate_recovery_project(project):
    source=project.get('source')
    if source is not None:
        if not isinstance(source,dict)or source.get('kind')!='vsp3'or source.get('units')not in FACTORS:raise ValueError('Повреждён исходный VSP3 в проекте восстановления.')
        geoms(source.get('xml'))


class Studio(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, config, executable=None, port=0):
        super().__init__(('127.0.0.1', port), Handler)
        self.origin = f'http://127.0.0.1:{self.server_port}'
        self.token = secrets.token_urlsafe(32)
        self.config_path = Path(config)
        self.recovery=RecoveryStore(self.config_path.parent/'Recovery',validate_recovery_project)
        self.startup_warnings=[]
        self.busy = threading.Lock()
        self.jobs = Jobs(self.busy,self.run_job)
        self.executable = None
        self.calculations = self.config_path.parent/'Calculations'
        interrupted=recover_interrupted(self.calculations)
        if interrupted:self.startup_warnings.append('Прерванных расчётных серий: '+str(len(interrupted))+'. Допуск не выдан.')
        stored,settings_warnings=read_settings(self.config_path)
        self.startup_warnings.extend(settings_warnings)
        self.machline=stored.get('machline') or discover_machline(ROOT)
        if executable:
            self.executable = validate_executable(executable)
        else:
            try:
                self.executable = validate_executable(stored.get('executable'))
            except (OSError, ValueError, TypeError):
                candidates=discover_executables()
                if candidates:self.executable=validate_executable(candidates[0])

    def server_close(self):
        if hasattr(self,'jobs'):self.jobs.close()
        super().server_close()

    def run_job(self,kind,data,progress):
        geoms(data.get('xml'))
        if data.get('units')not in FACTORS:raise ValueError('Проверь единицы модели.')
        if not self.executable:raise ValueError('Сначала подключи OpenVSP 3.51.')
        if kind=='assembly':
            progress('Нативная сетка и карта пространственных зазоров',.1)
            return assembly(self.executable,ROOT,data)
        if kind=='autofit':return repair_assembly(self.executable,ROOT,data,geoms,progress)
        if kind=='calculation':return run_pipeline(self.executable,self.machline,ROOT,self.calculations,data,progress)
        raise ValueError('Неизвестный вид фоновой проверки.')

    def audit(self, data, repair=False):
        geoms(data.get('xml'))
        if data.get('units') not in ('ft', 'm', 'mm', 'in') or data.get('preset') not in ('source', 'hybrid'):
            raise ValueError('Проверь единицы и режим сетки.')
        if repair:
            geoms(data.get('candidateXml'))
        if data.get('solver', 'vspaero') not in ('vspaero','machline'):
            raise ValueError('Неизвестный решатель проверки.')
        if data.get('solver')=='machline':
            machline_settings(data.get('machline'))
        if not self.busy.acquire(blocking=False):
            raise ValueError('OpenVSP занят. Дождись завершения текущей задачи.')
        try:
            if not self.executable:
                raise ValueError('Сначала выбери vspscript.exe кнопкой «Настроить OpenVSP».')
            if repair:
                return verify_repair(self.executable, ROOT, data, geoms)
            if data.get('solver')=='machline':
                return {'ok':True,'report':build_machline_mesh(self.executable,ROOT,data['xml'],data['units'],data.get('machline'))}
            return {'ok': True, 'report': build_mesh(self.executable, ROOT, data['xml'], data['units'], data['preset'])}
        finally:
            self.busy.release()

    def prepare(self, data):
        xml, kind = data.get('xml'), data.get('kind')
        source = geoms(xml)
        if kind == 'sections':
            chosen = data.get('selection')
            if not isinstance(chosen, list) or not 1<=len(chosen)<=32 or len(set(chosen)) != len(chosen):
                raise ValueError('Выбери от 1 до 32 разных компонентов FUSELAGE.')
            if any(not isinstance(i, str) or i not in source or source[i][0].lower() != 'fuselage' for i in chosen):
                raise ValueError('Выбранный компонент не является FUSELAGE.')
            script = (ROOT / 'native/sections.vspscript').read_text(encoding='utf-8')
            script = script.replace('"SS_SELECTED"', ','.join(json.dumps(i) for i in chosen))
            output = 'Source_prepared.vsp3'
        elif kind == 'wings':
            units = data.get('units')
            if units not in ('ft', 'm', 'mm', 'in'):
                raise ValueError('Проверь единицы модели.')
            if not any(v[0].lower() == 'wing' for v in source.values()):
                raise ValueError('В модели нет компонента Wing.')
            script = (ROOT / f'native/wings_{units}.vspscript').read_text(encoding='utf-8')
            output = 'WingData.json'
        else:
            raise ValueError('Неизвестный вид подготовки.')
        if not self.busy.acquire(blocking=False):
            raise ValueError('OpenVSP занят подготовкой. Дождись завершения.')
        try:
            if not self.executable:
                raise ValueError('Сначала выбери vspscript.exe кнопкой «Настроить OpenVSP».')
            with tempfile.TemporaryDirectory(prefix='SectionStudio_') as name:
                folder = Path(name)
                (folder / 'Source.vsp3').write_bytes(xml.encode('utf-8'))
                (folder / 'Prepare.vspscript').write_bytes(script.encode('utf-8'))
                with (folder / 'run.log').open('wb') as log:
                    try:
                        run = subprocess.run([self.executable, '-script', 'Prepare.vspscript'], cwd=folder,
                                             stdout=log, stderr=subprocess.STDOUT, timeout=180,
                                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                    except subprocess.TimeoutExpired as exc:
                        raise ValueError('OpenVSP не завершил подготовку за 180 секунд. Модель не изменена.') from exc
                    except OSError as exc:
                        raise ValueError('Не удалось запустить vspscript. Проверь путь и комплект DLL OpenVSP.') from exc
                with (folder / 'run.log').open('rb') as log:
                    message = log.read(12000).decode('utf-8', errors='replace')
                file = folder / output
                if 'SECTION_STUDIO_ERROR' in message or f'SECTION_STUDIO_SAVED: {output}' not in message or run.returncode != 0 or not file.is_file():
                    raise ValueError('OpenVSP не подготовил модель.\n'+(process_failure(run.returncode)+'\n'if run.returncode else'')+message[-6000:])
                if file.stat().st_size > MAX_INPUT:
                    raise ValueError('Результат подготовки превышает 64 МБ.')
                content = file.read_text(encoding='utf-8')
                if kind == 'sections':
                    return {'ok': True, 'xml': merge_selected(xml, content, chosen)}
                return {'ok': True, 'wingData': json.loads(content)}
        finally:
            self.busy.release()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def allowed(self, api=False):
        if self.headers.get('Host') != self.server.origin.removeprefix('http://'):
            return False
        origin = self.headers.get('Origin')
        if origin is not None and origin != self.server.origin:
            return False
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            return False
        return not api or secrets.compare_digest(self.headers.get('X-Section-Studio', ''), self.server.token)

    def send(self, status, value, mime='application/json; charset=utf-8'):
        payload = json.dumps(value, ensure_ascii=False).encode('utf-8') if isinstance(value, dict) else value
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "frame-ancestors 'none'")
        self.end_headers()
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if not self.allowed(self.path.startswith('/api/')and self.path!='/api/instance'):
            return self.send(403, {'error': 'Недопустимый запрос.'})
        if self.path=='/api/instance':return self.send(200,{'ok':True,'instanceId':getattr(self.server,'instance_id',None),'version':VERSION})
        if self.path in ('/', '/Section_Studio.html'):
            html = (ROOT / 'Section_Studio.html').read_text(encoding='utf-8')
            config = json.dumps({'token': self.server.token})
            html = html.replace('<head>', '<head><script>window.SectionStudioLocalConfig=' + config + ';</script>', 1)
            return self.send(200, html.encode('utf-8'), 'text/html; charset=utf-8')
        if self.path == '/api/status':
            return self.send(200, {'ok': True, 'executable': self.server.executable, 'machline':self.server.machline, 'busy': self.server.busy.locked(), 'version': VERSION,'warnings':self.server.startup_warnings})
        if self.path == '/api/calculation-list':
            return self.send(200, {'ok':True,'reports':calculation_listing(self.server.calculations)})
        if self.path == '/api/calculation-demo':
            try:
                folder=ROOT/'Demonstrators/Body_control'
                return self.send(200,{'ok':True,'project':json.loads((folder/'project.json').read_text(encoding='utf-8')),'report':json.loads((folder/'report.json').read_text(encoding='utf-8'))})
            except (OSError,ValueError):return self.send(400,{'error':'Демонстратор отсутствует в этой сборке.'})
        if self.path == '/api/calculation-demo-bundle':
            p=ROOT/'Demonstrators/Body_control/Calculation_bundle.zip'
            if not p.is_file():return self.send(404,{'error':'Комплект демонстратора не найден.'})
            return self.send(200,p.read_bytes(),'application/zip')
        if self.path.startswith('/api/calculation-bundle/'):
            try:
                p=calculation_bundle(self.server.calculations,self.path.rsplit('/',1)[-1])
                return self.send(200,p.read_bytes(),'application/zip')
            except (OSError,ValueError) as exc:return self.send(400,{'error':str(exc)})
        if self.path == '/api/recovery-list':
            try:return self.send(200,self.server.recovery.listing())
            except OSError as exc:return self.send(400,{'error':'Автовосстановление недоступно: '+str(exc)})
        return self.send(404, {'error': 'Не найдено.'})

    def do_POST(self):
        if not self.allowed(True):
            return self.send(403, {'error': 'Недопустимый запрос.'})
        try:
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                raise ValueError('Нужен JSON.')
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= MAX_INPUT:
                raise ValueError('Недопустимый размер запроса.')
            self.connection.settimeout(15)
            data = json.loads(self.rfile.read(size).decode('utf-8'))
            if not isinstance(data, dict):
                raise ValueError('Нужен объект JSON.')
            if self.path=='/api/recovery-save':return self.send(200,self.server.recovery.save(data.get('project')))
            if self.path=='/api/recovery-load':return self.send(200,self.server.recovery.load(data.get('id')))
            if self.path=='/api/calculation-report':return self.send(200,{'ok':True,'report':calculation_report(self.server.calculations,data.get('id'))})
            if self.path=='/api/engine':
                geoms(data.get('xml'))
                if not self.server.executable:raise ValueError('Сначала подключи OpenVSP 3.51.')
                if not self.server.busy.acquire(blocking=False):raise ValueError('OpenVSP занят. Дождись завершения задачи.')
                try:r=engine_update(self.server.executable,data['xml'],data.get('geomId'),data.get('changes'))
                finally:self.server.busy.release()
                return self.send(200,r)
            if self.path=='/api/configure-machline':
                if self.server.busy.locked():raise ValueError('Дождись завершения текущей задачи.')
                path=solver_path(data.get('executable'))
                if Path(path).name.lower() not in ('machline','machline.exe'):raise ValueError('Нужен исполняемый файл MachLine.')
                settings,_=read_settings(self.server.config_path);settings['machline']=path;write_settings(self.server.config_path,settings);self.server.machline=path
                return self.send(200,{'ok':True,'executable':path})
            if self.path in('/api/job-poll','/api/job-cancel'):
                ident=data.get('id')
                if not isinstance(ident,str)or not re.fullmatch(r'[a-f0-9]{24}',ident):raise ValueError('Неверный ID проверки.')
                return self.send(200,self.server.jobs.poll(ident)if self.path=='/api/job-poll'else self.server.jobs.cancel(ident))
            if self.path=='/api/job-start':
                kind,payload=data.get('kind'),data.get('payload')
                if kind not in('assembly','autofit','calculation')or not isinstance(payload,dict):raise ValueError('Неверная фоновая задача.')
                geoms(payload.get('xml'))
                if payload.get('units')not in FACTORS:raise ValueError('Проверь единицы модели.')
                if kind=='calculation':normalize_plan(payload.get('plan'),payload['xml'])
                return self.send(200,self.server.jobs.start(kind,payload))
            if self.path == '/api/configure':
                if self.server.busy.locked():
                    raise ValueError('Дождись завершения подготовки.')
                executable = validate_executable(data.get('executable'))
                self.server.config_path.parent.mkdir(parents=True, exist_ok=True)
                # Write settings before reporting success.
                settings,_=read_settings(self.server.config_path);settings['executable']=executable;write_settings(self.server.config_path,settings)
                self.server.executable = executable
                return self.send(200, {'ok': True, 'executable': executable})
            if self.path == '/api/pick':
                # The user's explicit button opens the native file dialog.
                import tkinter as tk
                from tkinter import filedialog
                window = tk.Tk()
                window.withdraw()
                window.attributes('-topmost', True)
                try:
                    selected = filedialog.askopenfilename(title='Выбери vspscript.exe из OpenVSP', parent=window)
                finally:
                    window.destroy()
                return self.send(200, {'ok': True, 'executable': selected})
            if self.path == '/api/prepare':
                return self.send(200, self.server.prepare(data))
            if self.path in ('/api/assembly','/api/shape-compare'):
                geoms(data.get('xml'))
                if data.get('units') not in FACTORS:
                    raise ValueError('Проверь единицы модели.')
                if self.path=='/api/shape-compare':geoms(data.get('originalXml'))
                if not self.server.executable:raise ValueError('Сначала подключи OpenVSP 3.51.')
                if not self.server.busy.acquire(blocking=False):raise ValueError('OpenVSP занят. Дождись завершения проверки.')
                try:
                    result=(assembly if self.path=='/api/assembly'else compare)(self.server.executable,ROOT,data)
                finally:self.server.busy.release()
                return self.send(200,result)
            if self.path == '/api/audit':
                return self.send(200, self.server.audit(data))
            if self.path == '/api/machline-tri':
                text=data.get('tri');units=data.get('units')
                if not isinstance(text,str) or len(text.encode('utf-8'))>40_000_000 or units not in FACTORS:
                    raise ValueError('Нужен ASCII TRI до 40 МБ с заданными единицами.')
                machline_settings(data.get('machline'))
                if not self.server.busy.acquire(blocking=False):
                    raise ValueError('Дождись завершения текущей проверки.')
                try:
                    with tempfile.TemporaryDirectory(prefix='StudioTri_') as folder:
                        path=Path(folder)/'Mesh.tri';path.write_text(text,encoding='utf-8')
                        report=inspect_machline(read_tri(path,FACTORS[units]),data.get('machline'))
                    report.update(externalMesh=True,fileName=str(data.get('fileName','Mesh.tri'))[:160],
                                  openVSPVersion='ASCII TRI',thickSet=-1,thinSet=-1,useMode=False,symmetry=False,preset='external-tri',sourceUnits=units,
                                  sourceHash=hashlib.sha256(text.encode('utf-8')).hexdigest(),excludedComponents=[])
                    report['limits'].insert(0,'Внешняя TRI не сопоставлена текущему VSP3 и не используется для подтверждения ремонта модели.')
                finally:
                    self.server.busy.release()
                return self.send(200,{'ok':True,'report':report})
            if self.path == '/api/verify-repair':
                return self.send(200, self.server.audit(data, repair=True))
            return self.send(404, {'error': 'Не найдено.'})
        except (ValueError, TypeError, OSError, ImportError, RuntimeError) as exc:
            return self.send(400, {'error': str(exc)})
        except Exception:
            return self.send(500, {'error': 'Подготовка не выполнена. Исходная модель не изменена.'})


def main(argv=None):
    parser = argparse.ArgumentParser(description='Section Studio '+VERSION+' — local OpenVSP bridge')
    parser.add_argument('--vspscript')
    parser.add_argument('--machline')
    parser.add_argument('--port', type=int, default=0)
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--self-test',action='store_true')
    config_dir = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / '.config'))) / 'SectionStudio'
    parser.add_argument('--config', default=str(config_dir / 'settings.json'))
    args = parser.parse_args(argv)
    if args.self_test:
        server=Studio(args.config,args.vspscript,args.port)
        if args.machline:server.machline=solver_path(args.machline)
        result=self_test(ROOT,server);server.server_close();path=Path(args.config).parent/'Setup_check.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2));print('Report:',path);return 0 if result['passed']else 1
    with InstanceGuard(Path(args.config).parent/'instance.lock')as guard:
        if not guard.acquired:
            origin=guard.existing_origin();print('Section Studio is already running:',origin,flush=True)
            if not args.no_browser:webbrowser.open(origin)
            return 0
        server=Studio(args.config,args.vspscript,args.port);server.instance_id=guard.ident
        if args.machline:server.machline=solver_path(args.machline)
        guard.publish({'instanceId':guard.ident,'origin':server.origin,'version':VERSION,'pid':os.getpid()})
        print(f'Section Studio {VERSION}: {server.origin}',flush=True)
        print('Keep this window open. Ctrl+C stops the application.',flush=True)
        for warning in server.startup_warnings:print('Settings:',warning,flush=True)
        if not args.no_browser:webbrowser.open(server.origin)
        try:server.serve_forever()
        except KeyboardInterrupt:pass
        finally:server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
